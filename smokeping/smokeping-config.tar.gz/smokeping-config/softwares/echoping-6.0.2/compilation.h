#define COMPILATION_OPTIONS "echoping 6.0.2 compiled with cc on localhost.localdomain (x86_64-unknown-linux-gnu)\n at 2017-08-27 with options:\n\nHTTP: enabled\nICP: disabled \nOPENSSL: disabled \nGNUTLS: disabled \nSMTP: enabled\nLIBIDN: disabled \nTOS: enabled\nPRIORITY: enabled\n\nPlugins are searched in /usr/local/lib/echoping."

/* $Id: compilation.h.in 377 2007-03-12 20:48:05Z bortz $ */
